import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Reserva = sequelize.define('Reserva', {
  nome: DataTypes.STRING,
  telefone: DataTypes.STRING,
  data: DataTypes.DATE
});

export default Reserva;
