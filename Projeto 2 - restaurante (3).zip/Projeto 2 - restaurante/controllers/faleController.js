const faleController = {
  newForm: (req, res) => res.render('faleForm'),
  criar: async (req, res) => {
    try {
      // Aqui você salva os dados do formulário
      res.render('success', { mensagem: 'Mensagem enviada com sucesso!' });
    } catch (err) {
      res.render('error', { mensagem: 'Erro ao enviar mensagem.' });
    }
  }
};

export default faleController;
