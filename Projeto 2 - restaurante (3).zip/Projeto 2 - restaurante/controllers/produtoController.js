import Produtos from '../models/produto.js';

const produtoController = {
    listAllProducts: async (req, res) => {
        try {
            const produtos = await Produtos.findAll({
                order: [['createdAt', 'DESC']]
            });
            res.render('produtos', {
                produtos: produtos.map(p => p.toJSON())
            });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao buscar produtos');
        }
    },

    showAddForm: (req, res) => {
        res.render('add_produto');
    },

    addNewProduct: async (req, res) => {
        const { nome, preco } = req.body;
        try {
            await Produtos.create({ nome, preco: parseFloat(preco) });
            res.redirect('/produtos');
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao adicionar produto');
        }
    },

    showEditForm: async (req, res) => {
        try {
            const produto = await Produtos.findByPk(req.params.id);
            if (!produto) return res.status(404).send('Produto não encontrado');
            res.render('edit_produto', { produto: produto.toJSON() });
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao buscar produto');
        }
    },

    updateProduct: async (req, res) => {
        const { nome, preco } = req.body;
        try {
            const produto = await Produtos.findByPk(req.params.id);
            if (!produto) return res.status(404).send('Produto não encontrado');
            produto.nome = nome;
            produto.preco = parseFloat(preco);
            await produto.save();
            res.redirect('/produtos');
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao atualizar produto');
        }
    },

    deleteProduct: async (req, res) => {
        try {
            const produto = await Produtos.findByPk(req.params.id);
            if (!produto) return res.status(404).send('Produto não encontrado');
            await produto.destroy();
            res.redirect('/produtos');
        } catch (error) {
            console.error(error);
            res.status(500).send('Erro ao deletar produto');
        }
    }
};

export default produtoController;
