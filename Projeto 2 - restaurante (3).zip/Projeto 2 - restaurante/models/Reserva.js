// models/Reserva.js
import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Reserva = sequelize.define('Reserva', {
  nome: { type: DataTypes.STRING, allowNull: false },
  telefone: { type: DataTypes.STRING, allowNull: false },
  data: { type: DataTypes.DATE, allowNull: false },
  pessoas: { type: DataTypes.INTEGER, allowNull: false }
});

export default Reserva;
