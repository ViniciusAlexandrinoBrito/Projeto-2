import express from 'express';
import bodyParser from 'body-parser';
import exphbs from 'express-handlebars';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import sequelize from './config/database.js';

import produtoRoutes from './routes/produtoRoutes.js';
import indexRoutes from './routes/indexRoutes.js';
import reservaRoutes from './routes/reservaRoutes.js';
import faleRoutes from './routes/faleRoutes.js';

dotenv.config();
const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3000;

// Body Parser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Static
app.use(express.static(path.join(__dirname, 'public')));

// Handlebars
app.engine('handlebars', exphbs.engine({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));

// Rotas
app.use('/', indexRoutes);         // Página inicial
app.use('/produtos', produtoRoutes); // Produtos
app.use('/reserva', reservaRoutes);  // Reservas
app.use('/fale', faleRoutes);        // Fale conosco

// Conexão DB e start server
sequelize.sync().then(() => {
    app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
}).catch(err => console.log('Erro ao conectar com o banco:', err));
