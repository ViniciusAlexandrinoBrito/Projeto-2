import express from 'express';
import reservaController from '../controllers/reservaController.js';
const router = express.Router();

router.get('/new', reservaController.newForm);
router.post('/add', reservaController.criar);

export default router;
