import express from 'express';
const router = express.Router();

router.get('/', (req, res) => res.render('home'));
router.get('/cardapio', (req, res) => res.redirect('/produtos')); // leva para a lista de produtos

export default router;
