import express from 'express';
import faleController from '../controllers/faleController.js';
const router = express.Router();

router.get('/new', faleController.newForm);
router.post('/add', faleController.criar);

export default router;
